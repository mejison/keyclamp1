# License

© Samuel Štancl 2020

You may use this boilerplate to build your own application.

You may not redistribute the boilerplate to third parties.

You may not redistribute parts of the boilerplate to third parties.
