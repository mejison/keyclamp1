<?php

namespace Tests;

use Illuminate\Database\Seeder;

class EmptySeeder extends Seeder
{
    public function run()
    {
        //
    }
}