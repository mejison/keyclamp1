<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCustomerColumns extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // Our tenants table migrations takes care of this
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        // Our tenants table migrations takes care of this
    }
}
